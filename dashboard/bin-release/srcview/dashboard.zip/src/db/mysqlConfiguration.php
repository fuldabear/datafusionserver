<?php

// connect to MySQL
$dbhost = 'localhost';
$dbuser = 'hmi';
$dbpass = 'hmi';
$dbname = 'hmi';

?>